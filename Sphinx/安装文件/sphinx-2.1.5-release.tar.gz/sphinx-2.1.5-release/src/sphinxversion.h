#define SPH_SVN_TAG "rel21"
#define SPH_SVN_REV 4508
#define SPH_SVN_REVSTR "4508"
#define SPH_SVN_TAGREV "rel21-r4508"
